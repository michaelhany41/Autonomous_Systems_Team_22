import rclpy
from rclpy.node import Node

from nav_msgs.msg import Odometry
from std_msgs.msg import Float64

import serial
import math

class PiConstraintNode(Node):

    def __init__(self):
        super().__init__('pi_constraint_node')

        # ---------------- Parameters ----------------
        self.declare_parameter('serial_port', '/dev/ttyACM0')
        self.declare_parameter('baud_rate', 115200)

        port = self.get_parameter('serial_port').value
        baud = self.get_parameter('baud_rate').value

        # ---------------- Serial Connection ----------------
        try:
            self.serial_conn = serial.Serial(port, baud, timeout=0.02)
            self.get_logger().info(f"Connected to Arduino on {port} at {baud} baud.")
        except serial.SerialException as e:
            self.get_logger().error(f"Failed to connect to serial port {port}: {e}")
            self.serial_conn = None

        # ---------------- Desired commands ----------------
        self.desired_speed = 0.0
        self.desired_steering = 0.0
        self.desired_lane = 1.0

        # ---------------- Subscribers ----------------
        self.create_subscription(
            Float64,
            '/desired_speed_cmd',
            self.speed_callback,
            10
        )

        self.create_subscription(
            Float64,
            '/desired_steering_cmd',
            self.steer_callback,
            10
        )

        self.create_subscription(
            Float64,
            '/desired_lane_cmd',
            self.lane_callback,
            10
        )

        # ---------------- Publisher ----------------
        self.odom_pub = self.create_publisher(
            Odometry,
            '/model/vehicle_blue/odometry',
            10
        )

        # ---------------- Timer ----------------
        self.dt = 0.05 # 20 Hz
        self.create_timer(self.dt, self.control_loop)

    def speed_callback(self, msg):
        self.desired_speed = msg.data

    def steer_callback(self, msg):
        self.desired_steering = msg.data

    def lane_callback(self, msg):
        self.desired_lane = msg.data

    def control_loop(self):
        # 1. Send commands to Arduino
        if self.serial_conn and self.serial_conn.is_open:
            # Saturation for steering (adjust as needed for hardware)
            delta = max(min(self.desired_steering, 0.6), -0.6)
            
            # Formatting command: "speed,steering\n"
            command_str = f"{self.desired_speed:.3f},{delta:.3f}\n"
            try:
                self.serial_conn.write(command_str.encode('utf-8'))
                self.get_logger().info(f"[TX] Sent to Arduino: {command_str.strip()}", throttle_duration_sec=1.0)
            except serial.SerialException as e:
                self.get_logger().error(f"Failed to write to serial: {e}")

            # 2. Read state from Arduino
            try:
                while self.serial_conn.in_waiting > 0:
                    line = self.serial_conn.readline().decode('utf-8', errors='ignore').strip()
                    if line:
                        self.parse_and_publish_odometry(line)
            except Exception as e:
                self.get_logger().error(f"Error reading from serial: {e}")

    def parse_and_publish_odometry(self, data_str):
        # Expected format from Arduino: "x,y,yaw,velocity"
        try:
            parts = data_str.split(',')
            if len(parts) >= 4:
                x = float(parts[0])
                y = float(parts[1])
                yaw = float(parts[2])
                v = float(parts[3])

                # Build Odometry message
                odom_msg = Odometry()
                odom_msg.header.stamp = self.get_clock().now().to_msg()
                odom_msg.header.frame_id = 'vehicle_blue/odom'
                odom_msg.child_frame_id = 'vehicle_blue/base_footprint'

                odom_msg.pose.pose.position.x = x
                odom_msg.pose.pose.position.y = y
                odom_msg.pose.pose.position.z = 0.0

                # Convert yaw to quaternion
                qz = math.sin(yaw / 2.0)
                qw = math.cos(yaw / 2.0)
                odom_msg.pose.pose.orientation.x = 0.0
                odom_msg.pose.pose.orientation.y = 0.0
                odom_msg.pose.pose.orientation.z = qz
                odom_msg.pose.pose.orientation.w = qw

                # Linear velocity
                odom_msg.twist.twist.linear.x = v
                odom_msg.twist.twist.linear.y = 0.0
                odom_msg.twist.twist.linear.z = 0.0
                
                # Angular velocity
                odom_msg.twist.twist.angular.x = 0.0
                odom_msg.twist.twist.angular.y = 0.0
                odom_msg.twist.twist.angular.z = 0.0 

                self.odom_pub.publish(odom_msg)
                
                self.get_logger().info(f"[RX] Odom from Arduino: x={x:.2f}, y={y:.2f}, yaw={yaw:.2f}, v={v:.2f}", throttle_duration_sec=1.0)

        except ValueError:
            # It might just be an info print from the arduino or incomplete string
            self.get_logger().debug(f"Could not parse as floats: {data_str}")

def main(args=None):
    rclpy.init(args=args)
    node = PiConstraintNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        if node.serial_conn and node.serial_conn.is_open:
            node.serial_conn.close()
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
