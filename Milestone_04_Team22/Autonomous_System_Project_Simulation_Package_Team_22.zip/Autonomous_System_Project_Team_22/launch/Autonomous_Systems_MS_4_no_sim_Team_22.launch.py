import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node

def generate_launch_description():

    # -------- Launch Arguments --------
    map_arg = DeclareLaunchArgument(
        'map',
        default_value='empty',
        description='Choose map: empty, racing, or city'
    )

    # -------- Planning Node --------
    planning_node = Node(
        package='Autonomous_System_Project_Team_22',
        executable='planning_node',
        name='planning_node',
        parameters=[
            {'map': LaunchConfiguration('map')}
        ],
        output='screen'
    )

    # -------- Speed Controller --------
    speed_node = Node(
        package='Autonomous_System_Project_Team_22',
        executable='speed_node',
        name='speed_node',
        output='screen'
    )

    # -------- Stanley Controller --------
    lateral_node = Node(
        package='Autonomous_System_Project_Team_22',
        executable='lateral_node',
        name='lateral_node',
        output='screen'
    )

    # -------- Constraint Node --------
    constraint_node = Node(
        package='Autonomous_System_Project_Team_22',
        executable='constraint_node',
        name='constraint_node',
        output='screen'
    )

    return LaunchDescription([
        map_arg,
        planning_node,
        speed_node,
        lateral_node,
        constraint_node
    ])
