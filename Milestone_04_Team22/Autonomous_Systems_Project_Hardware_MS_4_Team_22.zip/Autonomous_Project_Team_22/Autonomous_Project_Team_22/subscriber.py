import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
import serial

# Change port if needed
ser = serial.Serial('/dev/ttyACM0', 115200, timeout=1)


class PiNode(Node):

    def __init__(self):
        super().__init__('pi_subscriber')

        self.subscription = self.create_subscription(
            Twist,
            '/cmd_vel',
            self.callback,
            10
        )

        self.get_logger().info("Pi node started")

    def callback(self, msg):
        speed = msg.linear.x
        steering = msg.angular.z

        # Send to Arduino
        command = f"{speed:.2f},{steering:.2f}\n"
        ser.write(command.encode())

        self.get_logger().info(f"Sent → {command.strip()}")


def main(args=None):
    rclpy.init(args=args)
    node = PiNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
    ser.close()


if __name__ == '__main__':
    main()
