#include <Wire.h>
#include <MPU6050.h>
#include <Servo.h>

MPU6050 imu;

Servo steeringServo;


// ======================================================
// MOTOR PINS
// ======================================================

int IN1 = 8;
int IN2 = 7;
int ENA = 9;


// ======================================================
// SERVO PIN
// ======================================================

int servoPin = 10;


// ======================================================
// ENCODER
// ======================================================

volatile long encoderCount = 0;

int encA = 2;

long ticksPerRev = 330;

float wheelRadius = 0.03;


// ======================================================
// SPEED CONTROL
// ======================================================

float desiredSpeed = 0.0;
float measuredSpeed = 0.0;

float Kp = 30.0;
float Ki = 10.0;

float integral = 0.0;

int pwm = 0;


// ======================================================
// STEERING
// ======================================================

// desired steering from Pi
float desiredSteering = 0.0;

// servo center
int servoCenter = 90;

// max steering angle
int maxServoAngle = 35;


// ======================================================
// IMU + ODOMETRY
// ======================================================

float yaw = 0.0;

float gyroBiasZ = 0.0;

float posX = 0.0;
float posY = 0.0;


// ======================================================
// TIMING
// ======================================================

unsigned long prevTime = 0;

long prevCount = 0;


// ======================================================
// ENCODER INTERRUPT
// ======================================================

void tick()
{
    encoderCount++;
}


// ======================================================
// SETUP
// ======================================================

void setup()
{
    Serial.begin(115200);

    // --------------------------------------------------
    // MOTOR
    // --------------------------------------------------

    pinMode(IN1, OUTPUT);
    pinMode(IN2, OUTPUT);
    pinMode(ENA, OUTPUT);

    digitalWrite(IN1, HIGH);
    digitalWrite(IN2, LOW);

    analogWrite(ENA, 0);

    // --------------------------------------------------
    // SERVO
    // --------------------------------------------------

    steeringServo.attach(servoPin);

    steeringServo.write(servoCenter);

    // --------------------------------------------------
    // ENCODER
    // --------------------------------------------------

    pinMode(encA, INPUT_PULLUP);

    attachInterrupt(
        digitalPinToInterrupt(encA),
        tick,
        RISING
    );

    // --------------------------------------------------
    // IMU
    // --------------------------------------------------

    Wire.begin();

    imu.initialize();

    if(!imu.testConnection())
    {
        Serial.println("IMU FAILED");

        while(1);
    }

    Serial.println("MPU6050 CONNECTED");

    // --------------------------------------------------
    // GYRO CALIBRATION
    // --------------------------------------------------

    Serial.println("Calibrating gyro...");

    long sum = 0;

    for(int i = 0; i < 1000; i++)
    {
        int16_t gx, gy, gz;

        imu.getRotation(
            &gx,
            &gy,
            &gz
        );

        sum += gz;

        delay(2);
    }

    gyroBiasZ = sum / 1000.0;

    Serial.print("Gyro Bias Z: ");
    Serial.println(gyroBiasZ);

    prevTime = millis();

    Serial.println("READY");

    Serial.println("Send:");
    Serial.println("speed,steering");
    Serial.println("Example:");
    Serial.println("0.30,15");
}


// ======================================================
// MAIN LOOP
// ======================================================

void loop()
{
    // ==================================================
    // RECEIVE COMMAND FROM PI
    // FORMAT:
    // speed,steering
    // Example:
    // 0.30,15
    // ==================================================

    if(Serial.available() > 0)
    {
        String line =
            Serial.readStringUntil('\n');

        int commaIndex =
            line.indexOf(',');

        if(commaIndex > 0)
        {
            String speedStr =
                line.substring(
                    0,
                    commaIndex
                );

            String steeringStr =
                line.substring(
                    commaIndex + 1
                );

            desiredSpeed =
                speedStr.toFloat();

            desiredSteering =
                steeringStr.toFloat();
        }
    }


    // ==================================================
    // CONTROL LOOP EVERY 100 ms
    // ==================================================

    if(millis() - prevTime >= 100)
    {
        float dt =
            (millis() - prevTime)
            / 1000.0;

        prevTime = millis();


        // ==================================================
        // ENCODER SPEED
        // ==================================================

        noInterrupts();

        long count = encoderCount;

        interrupts();

        long delta =
            count - prevCount;

        prevCount = count;


        float omega =
            (delta * 2.0 * PI) /
            (ticksPerRev * dt);


        measuredSpeed =
            omega * wheelRadius;


        // ==================================================
        // PI SPEED CONTROLLER
        // ==================================================

        float error =
            desiredSpeed -
            measuredSpeed;


        integral += error * dt;


        integral =
            constrain(
                integral,
                -0.5,
                 0.5
            );


        pwm =
            Kp * error
            +
            Ki * integral;


        pwm =
            constrain(
                pwm,
                0,
                255
            );


        analogWrite(
            ENA,
            pwm
        );


        // ==================================================
        // STEERING CONTROL
        // ==================================================

        // Convert the incoming steering (radians) to degrees
        float desiredSteeringDeg = desiredSteering * 180.0 / PI;

        desiredSteeringDeg =
            constrain(
                desiredSteeringDeg,
                -maxServoAngle,
                 maxServoAngle
            );

        int servoCommand =
            servoCenter +
            desiredSteeringDeg;

        steeringServo.write(
            servoCommand
        );


        // ==================================================
        // IMU READ
        // ==================================================

        int16_t ax, ay, az;
        int16_t gx, gy, gz;

        imu.getMotion6(
            &ax,
            &ay,
            &az,
            &gx,
            &gy,
            &gz
        );


        // ==================================================
        // YAW ESTIMATION
        // ==================================================

        float gyroZ =
            (gz - gyroBiasZ) / 131.0;


        yaw += gyroZ * dt;


        float yawRad =
            yaw * PI / 180.0;


        // ==================================================
        // POSITION ESTIMATION
        // ==================================================

        posX +=
            measuredSpeed *
            cos(yawRad) *
            dt;

        posY +=
            measuredSpeed *
            sin(yawRad) *
            dt;


        // ==================================================
        // SEND ODOMETRY TO PI
        // FORMAT:
        // x,y,yaw,speed,pwm
        // ==================================================

        Serial.print(posX);
        Serial.print(",");

        Serial.print(posY);
        Serial.print(",");

        Serial.print(yawRad);
        Serial.print(",");

        Serial.print(measuredSpeed);
        Serial.print(",");

        Serial.println(pwm);
    }
}
