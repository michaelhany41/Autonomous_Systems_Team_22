from setuptools import find_packages, setup

package_name = 'Autonomous_Project_Team_22'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
   	 (
       		 'share/ament_index/resource_index/packages',
        	['resource/' + package_name],
    	),

    	(
        	'share/' + package_name,
        	['package.xml'],
   	 ),

   	 (
        	'share/' + package_name + '/launch',
        	['launch/Autonomous_Systems_MS_4_Team_22.launch.py'],
   	 ),
	],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='mypi4',
    maintainer_email='mypi4@todo.todo',
    description='TODO: Package description',
    license='Apache-2.0',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
    'console_scripts': [

        'lateral_node = Autonomous_Project_Team_22.lateral_Control:main',
        'speed_node = Autonomous_Project_Team_22.speed_Control:main',
        'constraint_node = Autonomous_Project_Team_22.vehicle_constraints:main',
	'planning_node = Autonomous_Project_Team_22.Autonomous_Systems_MS_4_Planning_Team_22:main',
	'subscriber_node = Autonomous_Project_Team_22.subscriber:main'
    	],
   },
)
