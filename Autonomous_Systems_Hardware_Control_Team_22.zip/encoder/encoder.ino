volatile long encoderCount = 0;


// ---------------- Motor Pins ----------------
int IN1 = 7;
int IN2 = 8;
int ENA = 9;


// ---------------- Encoder ----------------
int encA = 2;


// ---------------- Parameters ----------------
float wheelRadius = 0.03;

// 11 CPR × 30 gearbox
long ticksPerRev = 330;


// Desired and measured speed
float desiredSpeed = 0.0;
float measuredSpeed = 0.0;


// ---------- PI Gains ----------
float Kp = 350.0;
float Ki = 250.0;

float integral = 0.0;


// Base PWM to overcome deadzone
int basePWM = 0;

int pwm = 0;


// Timing
unsigned long prevTime = 0;
long prevCount = 0;



// ------------------------------------------------
// Encoder Interrupt
// ------------------------------------------------
void tick()
{
   encoderCount++;
}




// ------------------------------------------------
// Setup
// ------------------------------------------------
void setup()
{
  Serial.begin(115200);

  pinMode(IN1,OUTPUT);
  pinMode(IN2,OUTPUT);
  pinMode(ENA,OUTPUT);

  pinMode(encA,INPUT_PULLUP);


  attachInterrupt(
     digitalPinToInterrupt(encA),
     tick,
     RISING
  );


  // forward direction
  digitalWrite(IN1,HIGH);
  digitalWrite(IN2,LOW);

  analogWrite(ENA,0);


  Serial.println("PI Closed-loop speed controller ready");
  Serial.println("Send speed command:");
  Serial.println("0.20");
}




// ------------------------------------------------
// Main Loop
// ------------------------------------------------
void loop()
{

   // --------------------------------
   // Read desired speed command
   // --------------------------------
   if(Serial.available()>0)
   {
      String s=
      Serial.readStringUntil('\n');

      desiredSpeed=
      s.toFloat();

      Serial.print("Desired speed set: ");
      Serial.println(desiredSpeed);
   }




   // --------------------------------
   // Control loop every 100 ms
   // --------------------------------
   if(millis()-prevTime>=100)
   {

      float dt=
      (millis()-prevTime)/1000.0;

      prevTime=millis();



      // Safe encoder read
      noInterrupts();
      long count=encoderCount;
      interrupts();


      long delta=
      count-prevCount;

      prevCount=count;



      // --------------------------------
      // Compute measured speed
      // --------------------------------
      float omega=
      (delta*2.0*PI)/
      (ticksPerRev*dt);


      measuredSpeed=
      omega*wheelRadius;




      // --------------------------------
      // PI Controller
      // --------------------------------
      float error=
      desiredSpeed-
      measuredSpeed;



      // integral term
      integral += error*dt;


      // anti-windup
      integral=
      constrain(
         integral,
         -0.5,
          0.5
      );



      pwm=
      basePWM
      +
      Kp*error
      +
      Ki*integral;



      pwm=
      constrain(
         pwm,
         0,
         255
      );



      analogWrite(
         ENA,
         pwm
      );




      // --------------------------------
      // Debug output
      // --------------------------------
      Serial.print("Delta:");
      Serial.print(delta);

      Serial.print(" Ref:");
      Serial.print(desiredSpeed);

      Serial.print(" Speed:");
      Serial.print(measuredSpeed);

      Serial.print(" Error:");
      Serial.print(error);

      Serial.print(" Int:");
      Serial.print(integral);

      Serial.print(" PWM:");
      Serial.println(pwm);

   }

}
