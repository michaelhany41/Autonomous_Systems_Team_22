import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
from std_msgs.msg import Float64
import math


class LateralController(Node):

    def __init__(self):
        super().__init__('lateral_controller_stanley')

        self.declare_parameter('desired_y', 1.0)  # Desired speed in m/s
        # Parameters
        self.desired_y = self.get_parameter('desired_y').value
        self.k = 0.4  # Stanley gain

        # Global pose
        self.x = 0.0
        self.y = 0.0
        self.yaw = 0.0
        self.current_speed=0.0
        
        # Subscriber
        self.create_subscription(
            Odometry,
            '/model/vehicle_blue/odometry',
            self.odom_callback,
            10
        )

        # Publisher
        self.pub = self.create_publisher(
            Float64,
            '/desired_steering_cmd',
            10
        )

        self.lane_pub = self.create_publisher(
            Float64,
            '/desired_lane_cmd',
            10
        )
        
        # Control loop timer
        self.create_timer(0.1, self.control_loop)

    def odom_callback(self, msg):
        # -------- GLOBAL POSE --------
        self.x = msg.pose.pose.position.x
        self.y = msg.pose.pose.position.y
        
        # Velocity
        self.current_speed = msg.twist.twist.linear.x

        # Orientation (Quaternion → Yaw)
        q = msg.pose.pose.orientation
        siny = 2 * (q.w * q.z + q.x * q.y)
        cosy = 1 - 2 * (q.y * q.y + q.z * q.z)
        self.yaw = math.atan2(siny, cosy)

    def normalize_angle(self, angle):
        while angle > math.pi:
            angle -= 2.0 * math.pi
        while angle < -math.pi:
            angle += 2.0 * math.pi
        return angle

    def control_loop(self):
        # -------- Global cross-track error --------
        cte = self.desired_y - self.y

        # -------- Desired road heading --------
        path_heading = 0.0

        # -------- Heading error --------
        heading_error = self.normalize_angle(path_heading - self.yaw)

        # -------- Speed safeguard --------
        v = max(abs(self.current_speed), 0.5)

        # -------- Stanley control law --------
        steering = heading_error + math.atan2(self.k * cte, v)

        # -------- Saturation --------
        steering = max(min(steering, 0.5), -0.5)

        # -------- Command --------
        msg=Float64()
        msg.data=steering
        self.pub.publish(msg)
        
        lane_msg = Float64()
        lane_msg.data = self.desired_y
        self.lane_pub.publish(lane_msg)
        # Debug
        # self.get_logger().info(
        #     f"GLOBAL X={self.x:.2f} Y={self.y:.2f} Yaw={self.yaw:.2f} "
        #     f"CTE: {cte:.2f}, Steering: {steering:.2f}"
        # )


def main():
    rclpy.init()
    node = LateralController()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()