import rclpy
from rclpy.node import Node

from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from std_msgs.msg import Float64

import math


class ConstraintNode(Node):

    def __init__(self):
        super().__init__('constraint_node')

        # ---------------- Vehicle params ----------------
        self.L = 0.32

        # ---------------- Desired commands ----------------
        self.desired_speed = 0.0
        self.desired_steering = 0.0

        # If your lateral node tracks constant desired lane:
        self.desired_lane = 1.0

        # ---------------- Actual states ----------------
        self.actual_speed = 0.0
        self.actual_lane = 0.0


        # ---------------- Subscribers ----------------
        self.create_subscription(
            Float64,
            '/desired_speed_cmd',
            self.speed_callback,
            10
        )

        self.create_subscription(
            Float64,
            '/desired_steering_cmd',
            self.steer_callback,
            10
        )

        self.create_subscription(
            Odometry,
            '/model/vehicle_blue/odometry',
            self.odom_callback,
            10
        )


        # ---------------- Publisher ----------------
        self.pub = self.create_publisher(
            Twist,
            '/model/vehicle_blue/cmd_vel',
            10
        )


        self.create_timer(
            0.05,
            self.control_loop
        )

        self.create_subscription(
            Float64,
            '/desired_lane_cmd',
            self.lane_callback,
            10
        )

    # -----------------------------------
    def speed_callback(self,msg):
        self.desired_speed = msg.data


    def steer_callback(self,msg):
        self.desired_steering = msg.data


    def odom_callback(self,msg):
        self.actual_speed = msg.twist.twist.linear.x
        self.actual_lane = msg.pose.pose.position.y

    def lane_callback(self,msg):
        self.desired_lane = msg.data


    # -----------------------------------
    def control_loop(self):

        # steering saturation
        delta = max(
            min(self.desired_steering,0.6),
            -0.6
        )


        # nonholonomic constraint
        omega = (
            self.desired_speed/self.L
        ) * math.tan(delta)



        # publish constrained command
        cmd = Twist()
        cmd.linear.x = self.desired_speed
        cmd.angular.z = omega

        self.pub.publish(cmd)



        # ---------------- Errors ----------------
        speed_error = (
            self.desired_speed
            - self.actual_speed
        )

        lane_error = (
            self.desired_lane
            - self.actual_lane
        )



        # ---------------- Debug print ----------------
        self.get_logger().info(

        f"\n"
        f"Desired Speed : {self.desired_speed:.2f} m/s\n"
        f"Actual Speed  : {self.actual_speed:.2f} m/s\n"
        f"Speed Error   : {speed_error:.2f}\n"
        f"\n"
        f"Desired Lane  : {self.desired_lane:.2f} m\n"
        f"Actual Lane   : {self.actual_lane:.2f} m\n"
        f"Lane Error    : {lane_error:.2f}\n"
        f"\n"
        f"Steering Cmd  : {delta:.2f} rad\n"
        f"Yaw Rate Cmd  : {omega:.2f} rad/s"
        )


def main():
    rclpy.init()

    node = ConstraintNode()

    rclpy.spin(node)

    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()