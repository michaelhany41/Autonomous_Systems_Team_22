import rclpy
from geometry_msgs.msg import Twist
import sys
import termios
import tty

speed = 0.0
steering = 0.0


def get_key():
    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)
        ch1 = sys.stdin.read(1)

        if ch1 == '\x1b':
            ch2 = sys.stdin.read(1)
            ch3 = sys.stdin.read(1)
            return ch1 + ch2 + ch3
        else:
            return ch1
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)


def main():
    global speed, steering

    rclpy.init()
    node = rclpy.create_node('teleop_laptop')

    pub = node.create_publisher(Twist, '/cmd_vel', 10)

    print("Teleop (Laptop): ↑ ↓ ← → | s stop | q quit")

    while True:
        key = get_key()

        if key == '\x1b[A':
            speed -= 0.5
        elif key == '\x1b[B':
            speed += 0.5
        elif key == '\x1b[C':
            steering += 0.1
        elif key == '\x1b[D':
            steering -= 0.1
        elif key == 's':
            speed = 0.0
            steering = 0.0
        elif key == 'q':
            break

        msg = Twist()
        msg.linear.x = speed
        msg.angular.z = steering

        pub.publish(msg)

        print(f"[Laptop] Speed: {speed:.2f}, Steering: {steering:.2f}")

        rclpy.spin_once(node, timeout_sec=0.01)

    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
