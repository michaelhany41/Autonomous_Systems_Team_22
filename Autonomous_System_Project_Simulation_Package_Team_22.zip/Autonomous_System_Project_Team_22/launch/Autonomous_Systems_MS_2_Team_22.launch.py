from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, ExecuteProcess, TimerAction
from launch.substitutions import LaunchConfiguration
from launch.conditions import IfCondition
from launch_ros.actions import Node
from launch.substitutions import PythonExpression

def generate_launch_description():

    # Launch argument to switch mode
    mode_arg = DeclareLaunchArgument(
        'mode',
        default_value='olr',  # options: olr or teleop
        description='Driving mode: olr or teleop'
    )

    mode = LaunchConfiguration('mode')

    # 1. Launch Gazebo (Ackermann world)
    gazebo = ExecuteProcess(
        cmd=['gz', 'sim', 'ackermann_steering.sdf'],
        output='screen'
    )

    # 2. Bridge
    bridge = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        arguments=[
            '/model/vehicle_blue/cmd_vel@geometry_msgs/msg/Twist@gz.msgs.Twist',
            '/model/vehicle_blue/odometry@nav_msgs/msg/Odometry@gz.msgs.Odometry'
        ],
        output='screen'
    )

    bridge_delay = TimerAction(
        period=3.0,
        actions=[bridge]
    )

    # 3. OLR node (only if mode == olr)
    olr_node = Node(
        package='Autonomous_System_Project_Team_22',
        executable='olr_node',
        condition=IfCondition(
            PythonExpression(["'", mode, "' == 'olr'"])
        ),
        output='screen'
    )

    # 4. Teleop node (only if mode == teleop)
    teleop_node = ExecuteProcess(
        cmd=['gnome-terminal', '--', 'ros2', 'run',
            'Autonomous_System_Project_Team_22', 'teleop_node'],
        condition=IfCondition(
            PythonExpression(["'", mode, "' == 'teleop'"])
        ),
        output='screen'
    )

    nodes_delay = TimerAction(
        period=5.0,
        actions=[olr_node, teleop_node]
    )

    # 5. rqt_graph
    rqt = ExecuteProcess(
        cmd=['rqt_graph'],
        output='screen'
    )

    rqt_delay = TimerAction(
        period=6.0,
        actions=[rqt]
    )

    return LaunchDescription([
        mode_arg,
        gazebo,
        bridge_delay,
        nodes_delay,
        rqt_delay
    ])
