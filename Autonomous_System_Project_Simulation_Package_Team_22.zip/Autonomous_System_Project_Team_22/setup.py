from setuptools import find_packages, setup

package_name = 'Autonomous_System_Project_Team_22'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/Autonomous_System_Project_Team_22/launch',
            ['launch/Autonomous_Systems_MS_2_Team_22.launch.py'])
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='michool',
    maintainer_email='michool@todo.todo',
    description='TODO: Package description',
    license='Apache-2.0',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
        'console_scripts': [
        'olr_node = Autonomous_System_Project_Team_22.Autonomous_Systems_MS_2_OLR_Team_22:main',
        'teleop_node = Autonomous_System_Project_Team_22.Autonomous_Systems_MS_2_Teleop_Team_22:main',
        ],
    },
)
