from setuptools import find_packages, setup

package_name = 'Autonomous_Systems_Project_Team_22'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='michool',
    maintainer_email='michool@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
        'console_scripts': ['Validation_Printing_Node_Team_22 = Autonomous_Systems_Project_Team_22.Validation_Printing_Node_Team_22:main',
        ],
    },
)
