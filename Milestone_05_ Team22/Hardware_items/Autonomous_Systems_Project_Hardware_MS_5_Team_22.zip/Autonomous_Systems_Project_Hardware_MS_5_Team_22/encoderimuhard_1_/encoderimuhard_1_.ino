#include <MPU6050.h>
#include <Servo.h>
#include <Wire.h>

MPU6050 imu;

Servo steeringServo;

// ======================================================
// MOTOR PINS
// ======================================================

int IN1 = 8;
int IN2 = 7;
int ENA = 5;

// ======================================================
// SERVO PIN
// ======================================================

int servoPin = 10;

// ======================================================
// ENCODER
// ======================================================

volatile long encoderCount = 0;

int encA = 2;
int encB = 3;

long ticksPerRev = 4700;

float wheelRadius = 0.033;

// ======================================================
// SPEED CONTROL (RPM-based PI — same as encoderimuhard)
// ======================================================

float desiredSpeed = 0.0;
float measuredSpeed = 0.0;

// PI gains (RPM domain)
float PI_KP = 1.5;
float PI_KI = 0.8;
float PI_INTEGRAL_MAX = 400.0;
int PI_PWM_MIN = 30;

float piIntegral = 0.0;
float currentRPM = 0.0;

int pwm = 0;

// ======================================================
// STEERING
// ======================================================

// desired steering from Pi
float desiredSteering = 0.0;

// servo center
int servoCenter = 85;

// max steering angle
int maxServoAngle = 35;

// ======================================================
// IMU + ODOMETRY
// ======================================================

float yaw = 0.0;

float gyroBiasZ = 0.0;

float posX = 0.0;
float posY = 0.0;

// ======================================================
// TIMING
// ======================================================

unsigned long prevTime = 0;

long prevCount = 0;

// ======================================================
// QUADRATURE ENCODER ISR (same as encoderimuhard)
// ======================================================

void encoderISR_A() {
  if (digitalRead(encA) != digitalRead(encB))
    encoderCount++;
  else
    encoderCount--;
}

void encoderISR_B() {
  if (digitalRead(encA) == digitalRead(encB))
    encoderCount++;
  else
    encoderCount--;
}

// ======================================================
// PI CONTROLLER (same as encoderimuhard)
// ======================================================

int computePI(float targetRPM, float actualRPM, float dt) {
  if (dt <= 0.0)
    return 0;

  float error = targetRPM - actualRPM;

  // Integral with anti-windup
  piIntegral += error * dt;
  piIntegral = constrain(piIntegral, -PI_INTEGRAL_MAX, PI_INTEGRAL_MAX);

  // PI output
  float output = PI_KP * error + PI_KI * piIntegral;

  // Convert to PWM (0-255)
  int pwmOut = (int)abs(output);
  pwmOut = constrain(pwmOut, 0, 255);

  // Apply minimum PWM threshold to overcome static friction
  if (abs(targetRPM) > 0.1 && pwmOut < PI_PWM_MIN && pwmOut > 0)
    pwmOut = PI_PWM_MIN;

  return pwmOut;
}

void resetPI() {
  piIntegral = 0.0;
}

// ======================================================
// SETUP
// ======================================================

void setup() {
  Serial.begin(115200);

  // --------------------------------------------------
  // MOTOR
  // --------------------------------------------------

  pinMode(IN1, OUTPUT);
  pinMode(IN2, OUTPUT);
  pinMode(ENA, OUTPUT);

  digitalWrite(IN1, HIGH);
  digitalWrite(IN2, LOW);

  analogWrite(ENA, 0);

  // --------------------------------------------------
  // SERVO
  // --------------------------------------------------

  steeringServo.attach(servoPin);

  steeringServo.write(servoCenter);

  // --------------------------------------------------
  // ENCODER
  // --------------------------------------------------

  pinMode(encA, INPUT_PULLUP);
  pinMode(encB, INPUT_PULLUP);

  attachInterrupt(digitalPinToInterrupt(encA), encoderISR_A, CHANGE);
  attachInterrupt(digitalPinToInterrupt(encB), encoderISR_B, CHANGE);

  // --------------------------------------------------
  // IMU
  // --------------------------------------------------

  Wire.begin();

  imu.initialize();

  if (!imu.testConnection()) {
    Serial.println("IMU FAILED");

    while (1)
      ;
  }

  Serial.println("MPU6050 CONNECTED");

  // --------------------------------------------------
  // GYRO CALIBRATION
  // --------------------------------------------------

  Serial.println("Calibrating gyro...");

  long sum = 0;

  for (int i = 0; i < 1000; i++) {
    int16_t gx, gy, gz;

    imu.getRotation(&gx, &gy, &gz);

    sum += gz;

    delay(2);
  }

  gyroBiasZ = sum / 1000.0;

  Serial.print("Gyro Bias Z: ");
  Serial.println(gyroBiasZ);

  prevTime = millis();

  Serial.println("READY");

  Serial.println("Send:");
  Serial.println("speed,steering");
  Serial.println("Example:");
  Serial.println("0.30,15");
}

// ======================================================
// SERIAL BUFFER
// ======================================================
char inputBuffer[32];
int inputIndex = 0;

// ======================================================
// MAIN LOOP
// ======================================================

void loop() {
  // ==================================================
  // RECEIVE COMMAND FROM PI
  // FORMAT:
  // speed,steering
  // Example:
  // 0.30,15
  // ==================================================

  while (Serial.available() > 0) {
    char c = Serial.read();
    if (c == '\n') {
      inputBuffer[inputIndex] = '\0';

      char *commaPos = strchr(inputBuffer, ',');
      if (commaPos != NULL) {
        *commaPos = '\0';
        desiredSpeed = atof(inputBuffer);
        desiredSteering = atof(commaPos + 1);
      }

      inputIndex = 0;
    } else if (c != '\r' && inputIndex < 31) {
      inputBuffer[inputIndex++] = c;
    }
  }

  // ==================================================
  // CONTROL LOOP EVERY 100 ms
  // ==================================================

  if (millis() - prevTime >= 100) {
    float dt = (millis() - prevTime) / 1000.0;

    prevTime = millis();

    // ==================================================
    // ENCODER SPEED
    // ==================================================

    noInterrupts();

    long count = encoderCount;

    interrupts();

    long delta = count - prevCount;

    prevCount = count;

    // ==================================================
    // RPM CALCULATION (same as encoderimuhard)
    // ==================================================

    currentRPM = ((float)abs(delta) / (float)ticksPerRev) * (60.0 / dt);

    // Convert RPM to linear speed for odometry
    measuredSpeed = currentRPM * 2.0 * PI * wheelRadius / 60.0;

    // ==================================================
    // PI SPEED CONTROLLER (RPM domain)
    // ==================================================

    // Direction
    if (desiredSpeed < 0) {
      digitalWrite(IN1, LOW);
      digitalWrite(IN2, HIGH);
    } else {
      digitalWrite(IN1, HIGH);
      digitalWrite(IN2, LOW);
    }

    // Convert desired speed (m/s) to target RPM
    float targetRPM = abs(desiredSpeed) * 60.0 / (2.0 * PI * wheelRadius);

    // Compute PI in RPM domain
    float signedRPM = (delta >= 0) ? currentRPM : -currentRPM;
    pwm = computePI(targetRPM, signedRPM, dt);

    // Stop condition
    if (abs(desiredSpeed) < 0.01) {
      pwm = 0;
      resetPI();
    }

    pwm = constrain(pwm, 0, 255);

    analogWrite(ENA, pwm);

    // ==================================================
    // STEERING CONTROL
    // ==================================================

    // Convert the incoming steering (radians) to degrees
    float desiredSteeringDeg = desiredSteering * 180.0 / PI;

    desiredSteeringDeg =
        constrain(desiredSteeringDeg, -maxServoAngle, maxServoAngle);

    int servoCommand = servoCenter - desiredSteeringDeg;

    steeringServo.write(servoCommand);

    // ==================================================
    // IMU READ
    // ==================================================

    int16_t ax, ay, az;
    int16_t gx, gy, gz;

    imu.getMotion6(&ax, &ay, &az, &gx, &gy, &gz);

    // ==================================================
    // YAW ESTIMATION
    // ==================================================

    float gyroZ = (gz - gyroBiasZ) / 131.0;

    yaw += gyroZ * dt;

    float yawRad = yaw * PI / 180.0;

    // ==================================================
    // POSITION ESTIMATION
    // ==================================================

    float reportedSpeed = measuredSpeed;
    if (desiredSpeed < 0) {
      reportedSpeed = -measuredSpeed;
    }

    posX += reportedSpeed * cos(yawRad) * dt;

    posY += reportedSpeed * sin(yawRad) * dt;

    // ==================================================
    // SEND ODOMETRY TO PI
    // FORMAT:
    // x,y,yaw,speed,pwm
    // ==================================================

    Serial.print(posX);
    Serial.print(",");

    Serial.print(posY);
    Serial.print(",");

    Serial.print(yawRad);
    Serial.print(",");

    Serial.print(reportedSpeed);
    Serial.print(",");

    Serial.println(pwm);
  }
}
