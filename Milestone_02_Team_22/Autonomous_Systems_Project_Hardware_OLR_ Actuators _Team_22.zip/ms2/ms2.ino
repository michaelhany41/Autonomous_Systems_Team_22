#include <Servo.h>

Servo steering;

// Motor pins
int IN1 = 7;
int IN2 = 8;
int ENA = 9;

// Debug LED
int LED = 13;

// Variables
String data = "";
float speed = 0.0;
float steer = 0.0;

void setup() {
  Serial.begin(115200);   // MUST match Raspberry Pi

  pinMode(IN1, OUTPUT);
  pinMode(IN2, OUTPUT);
  pinMode(ENA, OUTPUT);

  pinMode(LED, OUTPUT);

  steering.attach(3);
  steering.write(90); // center

  stopMotor();
}

void loop() {

  if (Serial.available()) {

    data = Serial.readStringUntil('\n');  // read full line
    data.trim();  // 🔥 remove \r and spaces

    int commaIndex = data.indexOf(',');

    if (commaIndex > 0) {

      // Split values
      String speedStr = data.substring(0, commaIndex);
      String steerStr = data.substring(commaIndex + 1);

      // Convert to float
      speed = speedStr.toFloat();
      steer = steerStr.toFloat();

      // 🔹 Debug using LED
      if (speed != 0) {
        digitalWrite(LED, HIGH);
      } else {
        digitalWrite(LED, LOW);
      }

      // -------- MOTOR CONTROL --------
      int pwm = constrain(abs(speed) * 120, 80, 255);  // scaled

      if (speed > 0.1) {
        forward(pwm);
      }
      else if (speed < -0.1) {
        backward(pwm);
      }
      else {
        stopMotor();
      }

      // -------- STEERING CONTROL --------
      int angle = 90 + steer * 50;   // scale steering
      angle = constrain(angle, 50, 130);

      steering.write(angle);
    }
  }
}

// -------- Motor Functions --------
void forward(int speedVal) {
  digitalWrite(IN1, HIGH);
  digitalWrite(IN2, LOW);
  analogWrite(ENA, speedVal);
}

void backward(int speedVal) {
  digitalWrite(IN1, LOW);
  digitalWrite(IN2, HIGH);
  analogWrite(ENA, speedVal);
}

void stopMotor() {
  digitalWrite(IN1, LOW);
  digitalWrite(IN2, LOW);
  analogWrite(ENA, 0);
}
