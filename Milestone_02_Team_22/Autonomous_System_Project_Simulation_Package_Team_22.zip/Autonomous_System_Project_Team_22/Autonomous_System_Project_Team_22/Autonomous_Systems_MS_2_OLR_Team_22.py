import rclpy
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry


# Global variables (simple approach)
linear_speed = 2.0
steering = 0.0


def odom_callback(msg):
    x = msg.pose.pose.position.x
    y = msg.pose.pose.position.y

    vx = msg.twist.twist.linear.x
    wz = msg.twist.twist.angular.z

    print(f"Position: ({x:.2f}, {y:.2f}) | Velocity: {vx:.2f} | Steering: {wz:.2f}")


def main(args=None):
    rclpy.init(args=args)

    node = rclpy.create_node('olr_node_simple')

    # Publisher
    pub = node.create_publisher(
        Twist,
        '/model/vehicle_blue/cmd_vel',
        10
    )

    # Subscriber
    node.create_subscription(
        Odometry,
        '/model/vehicle_blue/odometry',
        odom_callback,
        10
    )

    # Timer function
    def timer_callback():
        msg = Twist()
        msg.linear.x = linear_speed
        msg.angular.z = steering
        pub.publish(msg)

    # Run at 10 Hz
    node.create_timer(0.1, timer_callback)

    print("Simple OLR node running...")

    rclpy.spin(node)

    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
